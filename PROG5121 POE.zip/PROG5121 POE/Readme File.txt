Project Title:
A simple Java project for user authentication and Kanban task management.

Description:
This project consists of two Java classes: `LogIn` for user authentication and `KanbanApp` for managing Kanban tasks. Users can register, log in, and then manage tasks using the Kanban board functionality.

Prerequisites
- Java Development Kit (JDK)
- An integrated development environment (IDE) like IntelliJ or Eclips

Open the project in your chosen IDE.

Usage:
Run the LogIn class to register and log in a user.
Upon successful login, the KanbanApp will be launched.
Follow the prompts to manage Kanban tasks.

Features:
User registration and authentication.
Kanban task management with features like task creation, deletion, and reporting.